#!/user/bin/env python

# Copyright (c) 2024，WuChao D-Robotics.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# 注意: 此程序在RDK板端端运行
# Attention: This program runs on RDK board.

import cv2
import numpy as np
import os
from scipy.special import softmax
# from scipy.special import expit as sigmoid
from hobot_dnn import pyeasy_dnn as dnn  # BSP Python API

from time import time
import argparse
import logging 
from hobot_vio import libsrcampy as srcampy

# 日志模块配置
# logging configs
logging.basicConfig(
    level = logging.DEBUG,
    format = '[%(name)s] [%(asctime)s.%(msecs)03d] [%(levelname)s] %(message)s',
    datefmt='%H:%M:%S')
logger = logging.getLogger("RDK_YOLO")
def bgr2nv12_opencv(image):
    height, width = image.shape[0], image.shape[1]
    area = height * width
    yuv420p = cv2.cvtColor(image, cv2.COLOR_BGR2YUV_I420).reshape((area * 3 // 2,))
    y = yuv420p[:area] # Y分量：前area个元素
    uv_planar = yuv420p[area:].reshape((2, area // 4)) # UV分量：后面的元素，每2个元素分别为U和V分量
    uv_packed = uv_planar.transpose((1, 0)).reshape((area // 2,)) # 将UV分量交替排列为交错的UV格式
    nv12 = np.zeros_like(yuv420p) # 创建与原YUV数据形状相同的空数组用于存放NV12格式数据
    nv12[:height * width] = y # 将Y分量直接赋值到NV12数组的前部
    nv12[height * width:] = uv_packed  # 将交错的UV分量赋值到NV12数组的后部
    return  nv12
def main():
    parser = argparse.ArgumentParser()
    #models/yolov5s_672x672_nv12.bin
    parser.add_argument('--model-path', type=str, default='/home/sunrise/rdk_model_zoo/demos/detect/YOLOv5/models/yolov5n_tag_v7.0_detect_640x640_bayese_nv12.bin', #yolov5n_tag_v7.0_detect_640x640_bayese_nv12.bin
                        help="""Path to BPU Quantized *.bin Model.
                                RDK X3(Module): Bernoulli2.
                                RDK Ultra: Bayes.
                                RDK X5(Module): Bayes-e.
                                RDK S100: Nash-e.
                                RDK S100P: Nash-m.""") 
    parser.add_argument('--source', type=str, default='0',# /home/sunrise/rdk_model_zoo/demos/detect/YOLOv5/11.mp4
                       help='video/stream/file.txt path, or 0 for webcam')
    parser.add_argument('--output', type=str, default='output.mp4', 
                       help='output video path')
    parser.add_argument('--view-img', action='store_true', default=True,
                       help='show results')
    #parser.add_argument('--test-img', type=str, default='niao.jpg', help='Path to Load Test Image.')
    #parser.add_argument('--img-save-path', type=str, default='niao1.jpg', help='Path to Load Test Image.')
    parser.add_argument('--classes-num', type=int, default=200, help='Classes Num to Detect.')
    parser.add_argument('--iou-thres', type=float, default=0.4, help='IoU threshold.')
    parser.add_argument('--conf-thres', type=float, default=0.4, help='confidence threshold.')
    parser.add_argument('--anchors', type=lambda s: list(map(int, s.split(','))), 
                        default=[10, 13, 16, 30, 33, 23, 30, 61, 62, 45, 59, 119, 116, 90, 156, 198, 373, 326],
                        help='--anchors 10,13,16,30,33,23,30,61,62,45,59,119,116,90,156,198,373,326')
    parser.add_argument('--strides', type=lambda s: list(map(int, s.split(','))), 
                        default=[8, 16, 32],
                        help='--strides 8,16,32')
    opt = parser.parse_args()
    logger.info(opt)
    # 实例化
    model = YOLOv5_Detect(opt.model_path, opt.conf_thres, opt.iou_thres, opt.classes_num, opt.anchors, opt.strides)
    #读视频
    # 判断输入源类型
    webcam = opt.source.isnumeric() or opt.source.endswith('.txt') or \
             opt.source.lower().startswith(('rtsp://', 'rtmp://', 'http://', 'https://'))

    # 初始化视频源
    if webcam:
        cap = cv2.VideoCapture(int(opt.source) if opt.source.isnumeric() else opt.source)
        if not cap.isOpened():
            logger.error(f"无法打开视频源: {opt.source}")
            return
    else:
        # 文件模式
        if not os.path.isfile(opt.source):
            logger.error(f"文件不存在: {opt.source}")
            return
        cap = cv2.VideoCapture(opt.source)
        if not cap.isOpened():
            logger.error(f"无法打开视频文件，可能格式不支持: {opt.source}")
            return
    # 初始化Display
    disp = srcampy.Display()
    disp.display(0, 1920, 1080)  # 设置显示分辨率为1920x108
    # 初始化视频写入器
    vid_writer = None
    frame_count = 0
    MAX_FRAMES = 10000  # 安全限制，防止无限循环
    TIMEOUT = 30.0      # 30秒超时
    start_time = time()
    while cap.isOpened() and frame_count < MAX_FRAMES:
        # if time() - start_time > TIMEOUT:
        #     logger.warning("处理超时，强制退出")
        #     break
        ret, frame = cap.read()
        if not ret:
            logger.info("视频处理完成或视频源结束")
            break

        frame_count += 1

        # 准备输入数据
        input_tensor = model.bgr2nv12(frame)
        
        # 推理
        outputs = model.c2numpy(model.forward(input_tensor))
        
        # 后处理
        ids, scores, bboxes = model.postProcess(outputs)
        
        # 渲染结果
        for class_id, score, bbox in zip(ids, scores, bboxes):
            x1, y1, x2, y2 = bbox
            logger.debug("(%d, %d, %d, %d) -> %s: %.2f"%(x1,y1,x2,y2, coco_names[class_id], score))
            draw_detection(frame, (x1, y1, x2, y2), score, class_id)
        for class_id, score, bbox in zip(ids, scores, bboxes):
            draw_detection(frame, bbox, score, class_id)
    
        # 准备显示帧
        if frame.shape != (1080, 1920, 3):
            display_frame = cv2.resize(frame, (1920, 1080))
        else:
            display_frame = frame
    
    #     # 转换为NV12并显示
        nv12_frame = bgr2nv12_opencv(display_frame)
#         height, width = 1080, 1920

        # 保存结果
        if opt.output:
            if vid_writer is None:
                fps = cap.get(cv2.CAP_PROP_FPS)
                w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                vid_writer = cv2.VideoWriter(opt.output, 
                                           cv2.VideoWriter_fourcc(*'mp4v'), 
                                           fps, (w, h))
            vid_writer.write(frame)
    # 释放资源
    cap.release()
    if vid_writer:
        vid_writer.release()
    if opt.view_img:
        cv2.destroyAllWindows()
    logger.info(f"处理完成，共处理 {frame_count} 帧")


class BaseModel:
    def __init__(
        self,
        model_file: str
        ) -> None:
        # 加载BPU的bin模型, 打印相关参数
        # Load the quantized *.bin model and print its parameters
        try:
            begin_time = time()
            self.quantize_model = dnn.load(model_file)
            logger.debug("\033[1;31m" + "Load D-Robotics Quantize model time = %.2f ms"%(1000*(time() - begin_time)) + "\033[0m")
        except Exception as e:
            logger.error("❌ Failed to load model file: %s"%(model_file))
            logger.error("You can download the model file from the following docs: ./models/download.md") 
            logger.error(e)
            exit(1)

        logger.info("\033[1;32m" + "-> input tensors" + "\033[0m")
        for i, quantize_input in enumerate(self.quantize_model[0].inputs):
            logger.info(f"intput[{i}], name={quantize_input.name}, type={quantize_input.properties.dtype}, shape={quantize_input.properties.shape}")

        logger.info("\033[1;32m" + "-> output tensors" + "\033[0m")
        for i, quantize_input in enumerate(self.quantize_model[0].outputs):
            logger.info(f"output[{i}], name={quantize_input.name}, type={quantize_input.properties.dtype}, shape={quantize_input.properties.shape}")

        self.model_input_height, self.model_input_weight = self.quantize_model[0].inputs[0].properties.shape[2:4]

    def resizer(self, img: np.ndarray)->np.ndarray:
        img_h, img_w = img.shape[0:2]
        self.y_scale, self.x_scale = img_h/self.model_input_height, img_w/self.model_input_weight
        return cv2.resize(img, (self.model_input_height, self.model_input_weight), interpolation=cv2.INTER_NEAREST) # 利用resize重新开辟内存
    
    def preprocess(self, img: np.ndarray)->np.array:
        """
        Preprocesses an input image to prepare it for model inference.

        Args:
            img (np.ndarray): The input image in BGR format as a NumPy array.

        Returns:
            np.array: The preprocessed image tensor in NCHW format ready for model input.

        Procedure:
            1. Resizes the image to a specified dimension (`input_image_size`) using nearest neighbor interpolation.
            2. Converts the image color space from BGR to RGB.
            3. Transposes the dimensions of the image tensor to channel-first order (CHW).
            4. Adds a batch dimension, thus conforming to the NCHW format expected by many models.
            Note: Normalization to [0, 1] is assumed to be handled elsewhere based on configuration.
        """
        begin_time = time()

        input_tensor = self.resizer(img)
        input_tensor = cv2.cvtColor(input_tensor, cv2.COLOR_BGR2RGB)
        # input_tensor = np.array(input_tensor) / 255.0  # yaml文件中已经配置前处理
        input_tensor = np.transpose(input_tensor, (2, 0, 1))
        input_tensor = np.expand_dims(input_tensor, axis=0).astype(np.uint8)  # NCHW

        logger.debug("\033[1;31m" + f"pre process time = {1000*(time() - begin_time):.2f} ms" + "\033[0m")
        return input_tensor

    def bgr2nv12(self, bgr_img: np.ndarray) -> np.ndarray:
        """
        Convert a BGR image to the NV12 format.

        NV12 is a common video encoding format where the Y component (luminance) is full resolution,
        and the UV components (chrominance) are half-resolution and interleaved. This function first
        converts the BGR image to YUV 4:2:0 planar format, then rearranges the UV components to fit
        the NV12 format.

        Parameters:
        bgr_img (np.ndarray): The input BGR image array.

        Returns:
        np.ndarray: The converted NV12 format image array.
        """
        begin_time = time()
        bgr_img = self.resizer(bgr_img)
        height, width = bgr_img.shape[0], bgr_img.shape[1]
        area = height * width
        yuv420p = cv2.cvtColor(bgr_img, cv2.COLOR_BGR2YUV_I420).reshape((area * 3 // 2,))
        y = yuv420p[:area]
        uv_planar = yuv420p[area:].reshape((2, area // 4))
        uv_packed = uv_planar.transpose((1, 0)).reshape((area // 2,))
        nv12 = np.zeros_like(yuv420p)
        nv12[:height * width] = y
        nv12[height * width:] = uv_packed

        logger.debug("\033[1;31m" + f"bgr8 to nv12 time = {1000*(time() - begin_time):.2f} ms" + "\033[0m")
        return nv12


    def forward(self, input_tensor: np.array) -> list[dnn.pyDNNTensor]:
        begin_time = time()
        quantize_outputs = self.quantize_model[0].forward(input_tensor)
        logger.debug("\033[1;31m" + f"forward time = {1000*(time() - begin_time):.2f} ms" + "\033[0m")
        return quantize_outputs


    def c2numpy(self, outputs) -> list[np.array]:
        begin_time = time()
        outputs = [dnnTensor.buffer for dnnTensor in outputs]
        logger.debug("\033[1;31m" + f"c to numpy time = {1000*(time() - begin_time):.2f} ms" + "\033[0m")
        return outputs

class YOLOv5_Detect(BaseModel):
    def __init__(self, 
                model_file: str, 
                conf: float, 
                iou: float,
                nc: int,
                anchors: list,
                strides: list
                ):
        super().__init__(model_file)
        # 配置项目
        self.conf = conf
        self.iou = iou
        self.nc = 80
        self.strides = np.array(strides) 
        input_h, input_w = self.model_input_height, self.model_input_weight

        # strides的grid网格, 只需要生成一次
        s_grid = np.stack([np.tile(np.linspace(0.5, input_w//strides[0] - 0.5, input_w//strides[0]), reps=input_h//strides[0]), 
                            np.repeat(np.arange(0.5, input_h//strides[0] + 0.5, 1), input_w//strides[0])], axis=0).transpose(1,0)
        self.s_grid = np.hstack([s_grid, s_grid, s_grid]).reshape(-1, 2)

        m_grid = np.stack([np.tile(np.linspace(0.5, input_w//strides[1] - 0.5, input_w//strides[1]), reps=input_h//strides[1]), 
                            np.repeat(np.arange(0.5, input_h//strides[1] + 0.5, 1), input_w//strides[1])], axis=0).transpose(1,0)
        self.m_grid = np.hstack([m_grid, m_grid, m_grid]).reshape(-1, 2)

        l_grid = np.stack([np.tile(np.linspace(0.5, input_w//strides[2] - 0.5, input_w//strides[2]), reps=input_h//strides[2]), 
                            np.repeat(np.arange(0.5, input_h//strides[2] + 0.5, 1), input_w//strides[2])], axis=0).transpose(1,0)
        self.l_grid = np.hstack([l_grid, l_grid, l_grid]).reshape(-1, 2)

        logger.info(f"{self.s_grid.shape = }  {self.m_grid.shape = }  {self.l_grid.shape = }")

        # 用于广播的anchors, 只需要生成一次
        anchors = np.array(anchors).reshape(3, -1)
        self.s_anchors = np.tile(anchors[0], input_w//strides[0] * input_h//strides[0]).reshape(-1, 2)
        self.m_anchors = np.tile(anchors[1], input_w//strides[1] * input_h//strides[1]).reshape(-1, 2)
        self.l_anchors = np.tile(anchors[2], input_w//strides[2] * input_h//strides[2]).reshape(-1, 2)

        logger.info(f"{self.s_anchors.shape = }  {self.m_anchors.shape = }  {self.l_anchors.shape = }")

    def postProcess(self, outputs: list[np.ndarray]) -> tuple[list]:
        begin_time = time()
        params_per_anchor = outputs[0].shape[-1] // 3
        s_pred = outputs[0].reshape([80, 80, 3, params_per_anchor]).reshape(-1, params_per_anchor)
        m_pred = outputs[1].reshape([40, 40, 3, params_per_anchor]).reshape(-1, params_per_anchor)
        l_pred = outputs[2].reshape([20, 20, 3, params_per_anchor]).reshape(-1, params_per_anchor)
        # reshape
        # s_pred = outputs[0].reshape([-1, 6])  # (80*80*3, 6)
        # m_pred = outputs[1].reshape([-1, 6])   # (40*40*3, 6)
        # l_pred = outputs[2].reshape([-1, 6])   # (20*20*3, 6)

        # 调试信息
        print(f"s_pred shape: {s_pred.shape}, m_pred shape: {m_pred.shape}, l_pred shape: {l_pred.shape}")
        
        # 单类别处理（因为shape最后一维是6=5+1）
        # 置信度计算 (sigmoid处理)
        s_scores = 1 / (1 + np.exp(-s_pred[:, 4]))  # 只取conf，忽略class
        s_valid_indices = np.flatnonzero(s_scores >= self.conf)
        
        m_scores = 1 / (1 + np.exp(-m_pred[:, 4]))
        m_valid_indices = np.flatnonzero(m_scores >= self.conf)
        
        l_scores = 1 / (1 + np.exp(-l_pred[:, 4]))
        l_valid_indices = np.flatnonzero(l_scores >= self.conf)

        # 单类别ID（全部设为0）
        s_ids = s_pred[s_valid_indices, 5].astype(int)  # 取第5位作为类别ID
        m_ids = m_pred[m_valid_indices, 5].astype(int)
        l_ids = l_pred[l_valid_indices, 5].astype(int)
        # s_ids = np.zeros(len(s_valid_indices), dtype=int)
        # m_ids = np.zeros(len(m_valid_indices), dtype=int)
        # l_ids = np.zeros(len(l_valid_indices), dtype=int)

        # 特征解码
        def decode(pred, valid_indices, grid, anchors, stride):
            dxyhw = 1 / (1 + np.exp(-pred[valid_indices, :4]))
            xy = (dxyhw[:, 0:2] * 2.0 + grid[valid_indices, :] - 1.0) * stride
            wh = (dxyhw[:, 2:4] * 2.0) ** 2 * anchors[valid_indices, :]
            return np.concatenate([xy - wh * 0.5, xy + wh * 0.5], axis=-1)

        s_xyxy = decode(s_pred, s_valid_indices, self.s_grid, self.s_anchors, self.strides[0])
        m_xyxy = decode(m_pred, m_valid_indices, self.m_grid, self.m_anchors, self.strides[1])
        l_xyxy = decode(l_pred, l_valid_indices, self.l_grid, self.l_anchors, self.strides[2])

        # 合并结果
        xyxy = np.concatenate((s_xyxy, m_xyxy, l_xyxy), axis=0)
        scores = np.concatenate((s_scores[s_valid_indices], 
                                m_scores[m_valid_indices],
                                l_scores[l_valid_indices]), axis=0)
        ids = np.concatenate((s_ids, m_ids, l_ids), axis=0)

        # NMS
        indices = cv2.dnn.NMSBoxes(xyxy.tolist(), scores.tolist(), self.conf, self.iou)
        if len(indices) > 0:
            indices = indices.flatten().astype(np.int32)
        else:
            return np.array([]), np.array([]), np.array([])  # 空结果
        #indices = np.array(indices).flatten()

        # 尺度还原
        bboxes = (xyxy[indices] * np.array([self.x_scale, self.y_scale, 
                                        self.x_scale, self.y_scale])).astype(np.int32)

        logger.debug(f"Post Process time = {1000*(time() - begin_time):.2f} ms")
        return ids[indices], scores[indices], bboxes

coco_names = [
    'Black footed Albatross', 'Laysan Albatross', 'Sooty Albatross', 'Groove billed Ani',
    'Crested Auklet', 'Least Auklet', 'Parakeet Auklet', 'Rhinoceros Auklet',
    'Brewer Blackbird', 'Red winged Blackbird', 'Rusty Blackbird', 'Yellow headed Blackbird',
    'Bobolink', 'Indigo Bunting', 'Lazuli Bunting', 'Painted Bunting',
    'Cardinal', 'Spotted Catbird', 'Gray Catbird', 'Yellow breasted Chat',
    'Eastern Towhee', 'Chuck will Widow', 'Brandt Cormorant', 'Red faced Cormorant',
    'Pelagic Cormorant', 'Bronzed Cowbird', 'Shiny Cowbird', 'Brown Creeper',
    'American Crow', 'Fish Crow', 'Black billed Cuckoo', 'Mangrove Cuckoo',
    'Yellow billed Cuckoo', 'Gray crowned Rosy Finch', 'Purple Finch', 'Northern Flicker',
    'Acadian Flycatcher', 'Great Crested Flycatcher', 'Least Flycatcher', 'Olive sided Flycatcher',
    'Scissor tailed Flycatcher', 'Vermilion Flycatcher', 'Yellow bellied Flycatcher', 'Frigatebird',
    'Northern Fulmar', 'Gadwall', 'American Goldfinch', 'European Goldfinch',
    'Boat tailed Grackle', 'Eared Grebe', 'Horned Grebe', 'Pied billed Grebe',
    'Western Grebe', 'Blue Grosbeak', 'Evening Grosbeak', 'Pine Grosbeak',
    'Rose breasted Grosbeak', 'Pigeon Guillemot', 'California Gull', 'Glaucous winged Gull',
    'Heermann Gull', 'Herring Gull', 'Ivory Gull', 'Ring billed Gull',
    'Slaty backed Gull', 'Western Gull', 'Anna Hummingbird', 'Ruby throated Hummingbird',
    'Rufous Hummingbird', 'Green Violetear', 'Long tailed Jaeger', 'Pomarine Jaeger',
    'Blue Jay', 'Florida Jay', 'Green Jay', 'Dark eyed Junco',
    'Tropical Kingbird', 'Gray Kingbird', 'Belted Kingfisher', 'Green Kingfisher',
    'Pied Kingfisher', 'Ringed Kingfisher', 'White breasted Kingfisher', 'Red legged Kittiwake',
    'Horned Lark', 'Pacific Loon', 'Mallard', 'Western Meadowlark',
    'Hooded Merganser', 'Red breasted Merganser', 'Mockingbird', 'Nighthawk',
    'Clark Nutcracker', 'White breasted Nuthatch', 'Baltimore Oriole', 'Hooded Oriole',
    'Orchard Oriole', 'Scott Oriole', 'Ovenbird', 'Brown Pelican',
    'White Pelican', 'Western Wood Pewee', 'Sayornis', 'American Pipit',
    'Whip poor Will', 'Horned Puffin', 'Common Raven', 'White necked Raven',
    'American Redstart', 'Geococcyx', 'Loggerhead Shrike', 'Great Grey Shrike',
    'Baird Sparrow', 'Black throated Sparrow', 'Brewer Sparrow', 'Chipping Sparrow',
    'Clay colored Sparrow', 'House Sparrow', 'Field Sparrow', 'Fox Sparrow',
    'Grasshopper Sparrow', 'Harris Sparrow', 'Henslow Sparrow', 'Le Conte Sparrow',
    'Lincoln Sparrow', 'Nelson Sharp tailed Sparrow', 'Savannah Sparrow', 'Seaside Sparrow',
    'Song Sparrow', 'Tree Sparrow', 'Vesper Sparrow', 'White crowned Sparrow',
    'White throated Sparrow', 'Cape Glossy Starling', 'Bank Swallow', 'Barn Swallow',
    'Cliff Swallow', 'Tree Swallow', 'Scarlet Tanager', 'Summer Tanager',
    'Artic Tern', 'Black Tern', 'Caspian Tern', 'Common Tern',
    'Elegant Tern', 'Forsters Tern', 'Least Tern', 'Green tailed Towhee',
    'Brown Thrasher', 'Sage Thrasher', 'Black capped Vireo', 'Blue headed Vireo',
    'Philadelphia Vireo', 'Red eyed Vireo', 'Warbling Vireo', 'White eyed Vireo',
    'Yellow throated Vireo', 'Bay breasted Warbler', 'Black and white Warbler', 'Black throated Blue Warbler',
    'Blue winged Warbler', 'Canada Warbler', 'Cape May Warbler', 'Cerulean Warbler',
    'Chestnut sided Warbler', 'Golden winged Warbler', 'Hooded Warbler', 'Kentucky Warbler',
    'Magnolia Warbler', 'Mourning Warbler', 'Myrtle Warbler', 'Nashville Warbler',
    'Orange crowned Warbler', 'Palm Warbler', 'Pine Warbler', 'Prairie Warbler',
    'Prothonotary Warbler', 'Swainson Warbler', 'Tennessee Warbler', 'Wilson Warbler',
    'Worm eating Warbler', 'Yellow Warbler', 'Northern Waterthrush', 'Louisiana Waterthrush',
    'Bohemian Waxwing', 'Cedar Waxwing', 'American Three toed Woodpecker', 'Pileated Woodpecker',
    'Red bellied Woodpecker', 'Red cockaded Woodpecker', 'Red headed Woodpecker', 'Downy Woodpecker',
    'Bewick Wren', 'Cactus Wren', 'Carolina Wren', 'House Wren',
    'Marsh Wren', 'Rock Wren', 'Winter Wren', 'Common Yellowthroat',
    'niao'
]


rdk_colors = [
    (56, 56, 255), (151, 157, 255), (31, 112, 255), (29, 178, 255),(49, 210, 207), (10, 249, 72), (23, 204, 146), (134, 219, 61),
    (52, 147, 26), (187, 212, 0), (168, 153, 44), (255, 194, 0),(147, 69, 52), (255, 115, 100), (236, 24, 0), (255, 56, 132),
    (133, 0, 82), (255, 56, 203), (200, 149, 255), (199, 55, 255)]

def draw_detection(img: np.array, 
                   bbox,#: tuple[int, int, int, int],
                   score: float, 
                   class_id: int) -> None:
    """
    Draws a detection bounding box and label on the image.

    Parameters:
        img (np.array): The input image.
        bbox (tuple[int, int, int, int]): A tuple containing the bounding box coordinates (x1, y1, x2, y2).
        score (float): The detection score of the object.
        class_id (int): The class ID of the detected object.
    """
    x1, y1, x2, y2 = bbox
    color = rdk_colors[class_id%20]
    cv2.rectangle(img, (x1, y1), (x2, y2), color, 2)
    label = f"{coco_names[class_id]}: {score:.2f}"
    (label_width, label_height), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
    label_x, label_y = x1, y1 - 10 if y1 - 10 > label_height else y1 + 10
    cv2.rectangle(
        img, (label_x, label_y - label_height), (label_x + label_width, label_y + label_height), color, cv2.FILLED
    )
    cv2.putText(img, label, (label_x, label_y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)

if __name__ == "__main__":
    main()
